using Newtonsoft.Json;
using WebApplicationUsers.Classes;

var builder = WebApplication.CreateBuilder(new WebApplicationOptions { WebRootPath = "img" });
var app = builder.Build();
app.UseStaticFiles();
app.Run(async (context) =>
{
    if (context.Request.Path == "/account")
    {
        var form = context.Request.Form;
        string email = form["auth_email"];
        string password = form["auth_pass"];
        Users usersEmailOnly = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/GetUsersEmail?email={email}"));
        Users usersEmailPassword = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/GetUsersEmailPassword?email={email}&password={password}"));
        if (usersEmailPassword.UsersID == 0)
        {
            if (usersEmailOnly.UsersID == 0)
            {
                await context.Response.SendFileAsync("Pages/reg.html");
            }
            else
            {
                await context.Response.SendFileAsync("Pages/respas.html");
            }
        }
        else
        {
            await context.Response.SendFileAsync("Pages/home.html");
            if (usersEmailPassword.Patronymic == null)
                await context.Response.WriteAsync($"<div class=\"content\"><h2 class=\"j\"{usersEmailPassword.Surname}></h2><h2 class=\"j\"{usersEmailPassword.Name}></h2></div>");
            else
                await context.Response.WriteAsync($"<div class=\"content\"><h2 class=\"j\"{usersEmailPassword.Surname}></h2><h2 class=\"j\"{usersEmailPassword.Name}></h2><h2 class=\"j\"{usersEmailPassword.Patronymic}></h2></div>");
        }
    }
    if (context.Request.Path == "/")
    {
        await context.Response.SendFileAsync("Pages/index.html");
    }
    if (context.Request.Path == "/registration")
    {
        await context.Response.SendFileAsync("Pages/reg.html");
    }
    if (context.Request.Path == "/password_recovery")
    {
        await context.Response.SendFileAsync("Pages/respas.html");
    }
    if (context.Request.Path == "/password_recovery_form")
    {
        var form = context.Request.Form;
        string email = form["auth_email"];
        Users usersEmailOnly = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/GetUsersEmail?email={email}"));
        if (usersEmailOnly.UsersID == 0)
        {
            await context.Response.SendFileAsync("Pages/reg.html");
        }
        else
        {
            await context.Response.SendFileAsync("Pages/registrpass.html");
        }
    }
    if (context.Request.Path == "/change_password")
    {
        var form = context.Request.Form;
        string email = form["auth_email"];
        string password = form["auth_pass"];
        string password_confirm = form["auth_pass_confirm"];
        Users usersEmailOnly = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/GetUsersEmail?email={email}"));
        if (usersEmailOnly.UsersID == 0)
        {
            await context.Response.SendFileAsync("Pages/reg.html");
        }
        else
        {
            if (password == password_confirm)
            {
                Users users = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/UpdatePassword?email={email}&newPassword={password}"));
                await context.Response.SendFileAsync("Pages/index.html");
            }
        }
    }
    if (context.Request.Path == "/registration_new_user")
    {
        var form = context.Request.Form;
        string fio = form["auth_fio"];
        string email = form["auth_email"];
        string password = form["auth_pass"];
        string password_confirm = form["auth_pass_confirm"];
        if (password == password_confirm)
        {
            Users users = JsonConvert.DeserializeObject<Users>(HelpAPI.HelpJSON($"https://localhost:44363/api/PostUsers?email={email}&password={password}&name={fio}"));
            await context.Response.SendFileAsync("Pages/index.html");
        }
        else
        {
            return;
        }
    }
});
app.Run();