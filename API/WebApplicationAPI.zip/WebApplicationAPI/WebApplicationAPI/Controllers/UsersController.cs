﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplicationAPI.Entities;

namespace WebApplicationAPI.Controllers
{
    public class UsersController : ApiController
    {
        private WebApplicationDataBaseEntities db = new WebApplicationDataBaseEntities();

        public IQueryable<Users> GetUsers()
        {
            return db.Users;
        }

        [Route("api/GetUsersEmail")]
        [ResponseType(typeof(Users))]
        public IHttpActionResult GetUsersEmail(string email)
        {
            Users user = db.Users.FirstOrDefault(x => x.Email == email);
            if (user == null)
            {
                Users userNull = new Users();
                return Ok(userNull);
            }
            return Ok(user);
        }

        [Route("api/GetUsersEmailPassword")]
        [ResponseType(typeof(Users))]
        public IHttpActionResult GetUsersEmailPassword(string email, string password)
        {
            Users user = db.Users.FirstOrDefault(x => x.Email == email && x.Password == password);
            if (user == null)
            {
                Users userNull = new Users();
                return Ok(userNull);
            }
            return Ok(user);
        }

        [Route("api/UpdatePassword")]
        [ResponseType(typeof(Users))]
        [HttpGet]
        public IHttpActionResult UpdatePassword(string email, string newPassword)
        {
            Users user = db.Users.FirstOrDefault(x => x.Email == email);
            if (user == null)
            {
                Users userNull = new Users();
                return Ok(userNull);
            }
            else
            {
                db.UpdateUsersPassword(email, newPassword);
                db.SaveChanges();
            }
            return Ok(user);
        }

        [Route("api/PostUsers")]
        [ResponseType(typeof(Users))]
        [HttpGet]
        public IHttpActionResult PostUsers(string email, string password, string name)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string[] fio = name.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            byte[] imageData;
            using (FileStream fs = new FileStream($@"{AppDomain.CurrentDomain.BaseDirectory}\Res\avatar.png", FileMode.Open))
            {
                imageData = new byte[fs.Length];
                fs.Read(imageData, 0, imageData.Length);
            }
            if (fio.Length == 2)
                db.InsertUsers(email, password, fio[0], fio[1], null, imageData);
            if (fio.Length == 3)
                db.InsertUsers(email, password, fio[0], fio[1], fio[2], imageData);
            db.SaveChanges();
            Users users = db.Users.FirstOrDefault(x => x.Email == email);
            return Ok(users);
        }
    }
}